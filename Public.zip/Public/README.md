# Finflux-Assignment
Purpose of creating this website is to just showcase my work to the Company. 

## To execute this project just open index.html file in the browser.
